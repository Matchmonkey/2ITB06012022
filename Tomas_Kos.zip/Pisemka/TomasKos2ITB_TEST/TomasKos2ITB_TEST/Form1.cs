﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace TomasKos2ITB_TEST
{

    public partial class Form1 : Form
    {
        public static int[] pole;
        public int vysledek;
        
        public Form1()
        {
            
            InitializeComponent();
        }
        public static void VytvorPole()
        {
            pole = new int[50];
        }
        public static void Napln_pole()
        {

            Random rd = new Random();
            for (int i = 0; i < pole.Length; i++)
            {
                pole[i] = rd.Next(10, 100);
            }
            
        }
        public static int Logika_pole(int vysledek)
        {
            for (int i = 0; i < pole.Length; i++)
            {
                if (pole[i] % 2 == 0)
                {
                    pole[i]++;
                    vysledek = pole[i] / 10;
                    
                }
                
            }
            return vysledek;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            ctverec.Width += 5;
            ctverec.Height += 5;
            

        }

        private void ctverec_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            timer1.Enabled = true;
            textBox1.Text = vysledek.ToString();
            ctverec.Size = new Size(vysledek, vysledek);

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
   
}
